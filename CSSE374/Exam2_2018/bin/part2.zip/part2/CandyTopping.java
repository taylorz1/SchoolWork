package part2;

import part1.Topping;

public abstract class CandyTopping implements Topping {
public abstract String toString();
}
