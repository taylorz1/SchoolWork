package part2;

public class MnM extends CandyTopping {

	@Override
	public String toString() {
		
		return "MnM";
	}

}
