package part2;

public class ReesesPieces extends CandyTopping {

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Reeses Pieces";
	}

}
