package part1;

public class StrawberryTopping implements Topping{
	@Override
	public String toString() {
		return "Fresh Strawberry";
	}

}
