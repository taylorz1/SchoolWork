package part1;

public interface Topping {

	String toString();
}
