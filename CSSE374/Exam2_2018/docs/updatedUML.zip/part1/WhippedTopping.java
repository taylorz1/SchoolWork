package part1;

public class WhippedTopping implements Topping{
	@Override
	public String toString() {
		return "Whipped Topping";
	}
}
